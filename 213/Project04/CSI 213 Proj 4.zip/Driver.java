package Project04;

import java.io.FileNotFoundException;

public class Driver {
	
	public static void main(String [] args) throws TreeException, FileNotFoundException{
		Helper.start();
	}


}
