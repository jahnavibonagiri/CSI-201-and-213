package project03.twentyfourpoints;


public class GenericStack<E> implements GenericStackInterface<E>{
	  /**
	   * The list of objects of this stack
	   */
	  private java.util.ArrayList<E> list;
	  
}
