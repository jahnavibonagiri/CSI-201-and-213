package project03.twentyfourpoints;

import java.util.ArrayList;

//Note: No Static methods. Otherwise, no credits.
public class Expression {
	
	/**
	 * The content of this expression
	 */
	private String infix;
	
	
	public Expression(){
	}
	
	public Expression(String infix){
	}
	
	public ArrayList<String> infixToPostfix(){
    }
	
	public int evaluatePostfix(){
	}
	
	//Other methods
	//Helper methods
}
