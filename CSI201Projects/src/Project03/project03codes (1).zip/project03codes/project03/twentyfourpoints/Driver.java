package project03.twentyfourpoints;

/**
 * Displays 24-point game. 
 * @author Qi Wang
 * @version 1.0
 */
public class Driver {

	/**
	 * Displays 24-point game.
	 * @param args A reference to a string array
	 */
	public static void main(String[] args) {
	    new TwentyFourPointsFrame();
	  }
}
