package project03.twentyfourpoints;


public interface GenericStackInterface<E>{
	}
